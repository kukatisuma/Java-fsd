package com.simpli;

public class EProduct {
	
	String name="HP Laptop";
	float price;
	
	public String getName() {
		return name;
	}

}
